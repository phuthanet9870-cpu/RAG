/* Pre-rendered monster sprites: only atlas selection, translation and facing flip. */
window.MonsterSheets=(()=>{
 const data=window.MONSTER_DATA,images={},tracks=new WeakMap();
 const aliases={blob:'drop',slime:'drop',bird:'chick',beast:'hare',insect:'bee',moth:'moth',fish:'sawfish',serpent:'worm',golem:'cgolem',shroom:'bud',plant:'biter',bat:'glimbat',wisp:'nix',demi:'gob',knight:'forgotten',skull:'walker',frog:'frog',crab:'crab',dragon:'lavadrake',dummy:'dummy',mummy:'mummy',demon:'bell',kraken:'B4'};
 function idOf(m){return data[m.id]?m.id:data[m.d?.id]?m.d.id:(!m.id&&!m.d?.id?aliases[m.d?.shape]:null)}
 function height(m){return Math.max(m.boss?88:32,(m.r||14)*(m.boss?3.4:2.5))}
 function choose(m,t,force){const id=idOf(m);if(!id)return null;let st=tracks.get(m);if(!st){st={x:m.x||0,y:m.y||0,time:t,moving:false,distance:0,face:Math.cos(m.face||0)<0?-1:1};tracks.set(m,st)}
  if(st.time!==t){let dx=(m.x||0)-st.x,dy=(m.y||0)-st.y,ds=Math.hypot(dx,dy),dt=t-st.time;st.moving=dt>0&&ds>.001&&ds<Math.max(60,dt*1000);if(st.moving){st.distance+=ds;if(Math.abs(dx)>.05)st.face=dx<0?-1:1}st.x=m.x||0;st.y=m.y||0;st.time=t;}
  const frozen=(m.st?.freeze||0)>0;
  const action=force||(m.dead?'death':frozen?'idle':m.flash>0||m.hurtT>0?'hurt':m.anim?'attack':st.moving?'walk':'idle');
  const frames=data[id].animations[action];let phase=0;
  if(action==='attack'){phase=m.anim?m.anim.t/m.anim.d:(t%1);st.face=Math.cos(m.face||0)<0?-1:1;}
  else if(action==='walk')phase=(st.distance/14)%frames.length;
  else if(action==='idle')phase=(t+(m.bob||0))*.85%frames.length;
  let index=action==='attack'?Math.min(frames.length-1,Math.max(0,Math.floor(phase*frames.length))):Math.max(0,Math.floor(phase))%frames.length;
  return {id,action,slot:frames[index],face:st.face};
 }
 function draw(c,m,t,force){const pick=choose(m,t,force);if(!pick)return false;const im=images[pick.id],d=data[pick.id];if(!im?.naturalWidth)return false;const scale=height(m)/d.neutralHeight,baseFace=d.baseFace||-1;c.save();if(pick.face!==baseFace)c.scale(-1,1);if(m.flash>0&&!force)c.filter='brightness(1.4)';c.imageSmoothingEnabled=false;c.drawImage(im,pick.slot*128,0,128,128,-64*scale,-116*scale,128*scale,128*scale);c.restore();return true;}
 async function preload(){await Promise.all(Object.entries(data).map(async([id,d])=>{const im=new Image();im.src=d.src;images[id]=im;await im.decode()}))}
 return {choose,draw,preload,images,data,height,idOf};
})();

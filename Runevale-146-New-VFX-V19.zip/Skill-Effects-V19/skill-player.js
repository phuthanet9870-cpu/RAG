window.SkillEffects=(()=>{
 const data={...window.SKILL_FX_DATA,...(window.CAST_FX_DATA||{})},images={},events=[],stats={},learned=new WeakMap();let current=null;const stack=[];
 const renderStats={mainDraws:0,byId:{}};const blendCanvas=document.createElement('canvas');blendCanvas.width=blendCanvas.height=160;const blendContext=blendCanvas.getContext('2d');
 const alias={hn_mine_x:'hn_mine',hn_mine_t:'hn_mine',hn_ankle_t:'hn_ankle',hn_clay_t:'hn_clay',hn_clay_z:'hn_clay',al_bomb_z:'al_bomb',sg_seal_z:'sg_seal',st_poison:'as_cloud'};
 const idOf=id=>data[id]?id:alias[id];
 function log(id,phase,extra={}){if(!data[id])return;let s=stats[id]||(stats[id]={});s[phase]=(s[phase]||0)+1;events.push({id,phase,...extra});if(events.length>2048)events.shift()}
 function body(p){return p.y-(p.isMon&&window.MonsterSheets?MonsterSheets.height(p)*.5:34)}
 function blit(c,id,phase,x,y,o={}){
  id=idOf(id);const d=data[id],im=images[id];if(!d||!im?.naturalWidth)return false;
  const fc=d.frameCount||9,fs=d.frameSize||(im.naturalWidth/fc),slots=(o.slots||Array.from({length:fc},(_,i)=>i)).filter(i=>i>=0&&i<fc);if(!slots.length)return false;
  const p=Math.min(.999999,Math.max(0,phase))*slots.length,index=Math.min(slots.length-1,Math.floor(p)),i=Math.min(fc-1,o.slot??slots[index]),w=o.width||o.size||92,h=o.height||w;
  const anchor=d.anchor||[fs/2,fs/2],dx=-w*anchor[0]/fs,dy=-h*anchor[1]/fs;
  c.save();c.translate(x,y);if(o.angle)c.rotate(o.angle);c.imageSmoothingEnabled=true;c.imageSmoothingQuality='high';
  const alpha=c.globalAlpha*(o.alpha??.92);c.globalAlpha=alpha;
  // Soft energy blends with scene lighting; smoke, rocks and traps retain volume.
  const energy=!d.grounded&&!/cloud|quag|mine|ankle|clay|smash|hammer|bomb|meteor|heaven/.test(id);
  if(energy)c.globalCompositeOperation='screen';
  const mix=o.slot==null&&index<slots.length-1?Math.max(0,Math.min(1,(p-index-.12)/.88)):0;
  if(mix>0){if(blendCanvas.width!==fs){blendCanvas.width=blendCanvas.height=fs}const z=blendContext;z.clearRect(0,0,fs,fs);z.globalCompositeOperation='source-over';z.globalAlpha=1-mix;z.drawImage(im,i*fs,0,fs,fs,0,0,fs,fs);z.globalCompositeOperation='lighter';z.globalAlpha=mix;z.drawImage(im,slots[index+1]*fs,0,fs,fs,0,0,fs,fs);z.globalAlpha=1;z.globalCompositeOperation='source-over';c.drawImage(blendCanvas,dx,dy,w,h)}else c.drawImage(im,i*fs,0,fs,fs,dx,dy,w,h);
  c.restore();if(c.canvas?.id==='cv'){renderStats.mainDraws++;renderStats.byId[id]=(renderStats.byId[id]||0)+1}return true;
 }
 function emit(id,x,y,o={}){id=idOf(id);if(!data[id]||typeof W==='undefined'||!W?.fx||W.fx.length>400)return null;const f={kind:'skillV19',id,x,y,t:-(o.delay||0),life:o.life||data[id].duration||.72,...o};delete f.delay;W.fx.push(f);return f}
 function boundary(c,id,x,y,r,alpha=.2){if(!r)return;const el=data[id]?.element,col=el===3?'#ff9254':el===1?'#9beaff':el===4?'#d4b5ff':el===5?'#a1e880':id.startsWith('ro_')?'#bb92eb':'#e8d1a0';c.save();c.strokeStyle=col;c.globalAlpha*=alpha;c.lineWidth=1.25;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.stroke();c.restore()}
 function draw(c,f){if(f.t<0)return;let p=Math.max(0,Math.min(.999,f.t/f.life)),x=f.x,y=f.y,opts={...f};if(f.target&&f.follow){x=f.target.x;y=data[f.id]?.grounded?f.target.y:body(f.target)}if(f.projectile){let tx=f.target?f.target.x:f.tx,ty=f.target?body(f.target):f.ty;x=f.x+(tx-f.x)*p;y=f.y+(ty-f.y)*p;opts.angle=Math.atan2(ty-f.y,tx-f.x)-(f.baseAngle||0)}opts.alpha=(opts.alpha??.95)*Math.min(1,p*16,(1-p)*8);return blit(c,f.id,p,x,y,opts)}
 function begin(c){stack.push(current);current=c;c.v8Origin={x:c.src.x,y:c.src.y};c.v8Duration=data[c.s.id]?.duration||.72;c.v8Hit=false;c.v8Heal=false;c.v8Flight=false}
 function end(){current=stack.pop()||null}
 function timeline(c,o,t){if(!c?.s||!data[c.s.id])return;const hits=o.hits||1,span=(o.start||0)+(hits-1)*(o.delay||.06)+.4;c.v8Duration=Math.max(c.v8Duration||.72,span);if(!c.s&&hits>1)return;}
 function projectile(id,from,target,o={}){const tx=target.x,ty=body(target),sx=from.x,sy=body(from);return emit(id,sx,sy,{projectile:true,target,tx,ty,life:o.life||Math.max(.18,Math.min(.4,Math.hypot(tx-sx,ty-sy)/900)),slots:[1,2,3],size:82,alpha:.85,...o})}
 function impact(t,info,u){const id=idOf(info.src);if(!data[id])return false;log(id,'hit',{target:t.id||null});if(current?.s.id===id)current.v8Hit=true;if(info.src==='basic')return false;const m=data[id],ang=Math.atan2(t.y-u.y,t.x-u.x);
  // Rapid multi-hit damage shares one evolving impact instead of stacking opaque copies.
  for(let i=W.fx.length-1;i>=0;i--){const f=W.fx[i];if(f.id===id&&f.target===t&&!f.projectile&&f.t>=0&&f.t<.11){f.life=Math.max(f.life,f.t+.4);return true}}
  const stages=['projectile','dash'].includes(m.mode)?[4,5,6,7,8]:Array.from({length:m.frameCount||9},(_,i)=>i);
  return !!emit(id,t.x,body(t),{target:t,follow:false,size:Math.max(78,Math.min(128,(t.r||15)*4)),angle:(['projectile','dash'].includes(m.mode)||['sw_bash','kn_pierce','mo_asura','as_sonic','ro_back','th_steal'].includes(id))?ang:0,slots:stages,life:.65,alpha:.9})}
 function radius(c){return c.s.id==='kn_brand'&&c.src.peco?5*T:Math.max(0,(typeof c.s.r==='number'?c.s.r:0)*T)}
 function cast(c){const id=c.s.id,d=data[id];if(!d||d.type==='passive')return false;if(id==='hn_blitz'&&!c.src.falcon)return false;if(id==='al_potion'&&!c.v8Heal)return false;log(id,'cast',{level:c.lv});if(c.v8Heal)return true;if(id==='mo_orbs'){emit(id,c.src.x,c.src.y,{target:c.src,follow:true,size:96,life:.9,alpha:.9});return true;}let src=c.src,tg=c.t,ally=c.ally||src,org=c.v8Origin||{x:src.x,y:src.y},r=radius(c),p={x:c.x??tg?.x??src.x,y:c.y??tg?.y??src.y};const life=Math.min(2.5,c.v8Duration||d.duration||.72);
  if(['ac_heal','cr_heal'].includes(id)&&(tg?.isMon||!c.v8Heal))return true;
  if(d.mode==='trap')return true;
  if(d.persistentGround)return true;
  if(d.mode==='teleport'){emit(id,org.x,org.y,{size:74,life:.55});emit(id,src.x,src.y,{size:74,life:.65});return true}
  if(d.mode==='dash'){let dest=id==='cr_rush'?(tg||src):src,dx=dest.x-org.x,dy=dest.y-org.y;emit(id,(org.x+dest.x)/2,(org.y+dest.y)/2-24,{width:Math.max(72,Math.hypot(dx,dy)),height:65,angle:Math.atan2(dy,dx)-(id==='th_back'?Math.PI:0),life});return true}
  if(d.mode==='cone'){let a=tg?Math.atan2(tg.y-src.y,tg.x-src.x):src.face||0;emit(id,src.x,src.y,{cone:true,angle:a,r:6*T,halfAngle:35*Math.PI/180,life,layer:'ground',alpha:.7});return true}
  if(d.mode==='projectile'){if(c.v8Flight)return true;if(id==='al_acid')return true;if(c.v8Heal)return true;const dest=tg||c.ally||src;projectile(id,src,dest,{size:id==='ar_double'?74:64});return true}
  if(d.mode==='party'){for(let a of allyList(src)){if(dist(a,src)<=(d.partyRadius||13)*T)emit(id,a.x,a.y,{target:a,follow:true,size:78,life:1,alpha:.8})}return true}
  if(d.mode==='selfArea'||d.mode==='ground'||d.mode==='targetArea'){let pos=d.mode==='selfArea'?src:d.mode==='targetArea'?tg:p;if(!pos)pos=src;emit(id,pos.x,pos.y,{size:Math.max(70,r*2),radius:r,life,layer:'ground',alpha:.65});return true}
  if(d.mode==='ally'){if(!c.v8Heal)emit(id,ally.x,ally.y,{target:ally,follow:true,size:id==='pr_resu'?110:80,life:1});return true}
  if(d.mode==='self'||d.mode==='craft'){emit(id,src.x,src.y,{target:src,follow:true,size:80,life:1});return true}
  if(!c.v8Hit&&tg)emit(id,tg.x,body(tg),{size:76,life});return true;
 }
 function heal(u,value,src){if(!current?.s||!data[current.s.id])return;const id=current.s.id;if(!['firstaid','ac_heal','cr_heal','al_potion'].includes(id))return;current.v8Heal=true;log(id,'heal');if(id==='al_potion'){projectile(id,src||current.src,u);emit(id,u.x,u.y,{target:u,follow:true,size:96,life:.7,delay:.1,slots:[3,4,5,6,7,8]})}else emit(id,u.x,u.y,{target:u,follow:true,size:96,life:.8})}
 function learn(u,id){if(!data[id]||data[id].type!=='passive')return false;log(id,'learn');return !!emit(id,u.x,body(u),{target:u,follow:true,size:66,life:.8})}
 function observe(u){if(!u.skills)return;let old=learned.get(u);if(!old){old={...u.skills};learned.set(u,old);return}for(let [id,lv]of Object.entries(u.skills)){if(data[id]?.type==='passive'&&lv>(old[id]||0))learn(u,id);old[id]=lv}}
 function passive(u,id,t){if(!(u.skills?.[id]>0)||data[id]?.type!=='passive')return false;log(id,'proc');return !!emit(id,t?.x??u.x,t?body(t):body(u),{size:76,life:.6,angle:t?Math.atan2(t.y-u.y,t.x-u.x):0})}
 function basicHits(c,o,t){if(c.s)return;if(o.hits===3&&c.src.skills?.mo_triple)passive(c.src,'mo_triple',t);else if(o.hits===2&&c.src.wt==='dagger'&&c.src.skills?.th_double)passive(c.src,'th_double',t)}
 function regen(u,hp,sp){if(hp>0&&u.skills?.sw_regen)passive(u,'sw_regen');if(sp>0&&u.skills?.mg_sp)passive(u,'mg_sp')}
 function buffId(key,b){return idOf(b.sk||key)||(key==='oath'?'cr_oath':null)}
 function drawBuffs(c,u,t){observe(u);/* Persistent buff effects are hidden; skill activation and buff mechanics remain. */}
 const zoneFallback={pneuma:'wz_pneuma',quag:'wz_quag',blizzard:'wz_storm',magnus:'pr_magnus',sanct:'pr_sanct',safety:'pr_safety',seal:'sg_seal',firebomb:'al_bomb',burn:'hn_clay',water:'sg_water'};
 function ground(c,g,t){let id=idOf(g.sk)||zoneFallback[g.kind];if(!data[id])return false;let fade=Math.max(0,Math.min(1,g.t));return blit(c,id,(t*.8)%1,g.x,g.y,{slots:[1,2,3,4,5,6,7,6,5,4,3,2],size:g.r*2,alpha:.60*fade})}
 function trap(c,tr,t,mine){const id=tr.c?.s?.id||({mine:'hn_mine',ankle:'hn_ankle',clay:'hn_clay'}[tr.kind]);if(!data[id])return false;return blit(c,id,0,tr.x,tr.y,{slot:0,size:43,alpha:mine?.9:.45})}
 function trapTriggered(tr){const id=tr.c?.s?.id||({mine:'hn_mine',ankle:'hn_ankle',clay:'hn_clay'}[tr.kind]);log(id,'trigger');return emit(id,tr.x,tr.y,{slots:[3,4,5,6,7,8],size:Math.max(70,tr.r*2),life:.6,layer:'ground'})}
 function drawGrounds(c,t){for(let g of W.grounds)ground(c,g,t);for(let tr of W.traps)trap(c,tr,t,tr.owner===P);for(let f of W.fx)if(f.kind==='skillV19'&&f.layer==='ground')render(c,f)}
 const coneCanvas=document.createElement('canvas'),coneContext=coneCanvas.getContext('2d'),coneMasks=new Map();
 function render(c,f){
  if(!f.cone)return draw(c,f);if(f.t<0)return false;
  const w=Math.ceil(f.r+32),h=Math.ceil(2*f.r*Math.sin(f.halfAngle)+32),key=[w,h,f.halfAngle].join(':');let mask=coneMasks.get(key);
  if(!mask){mask=document.createElement('canvas');mask.width=w;mask.height=h;let m=mask.getContext('2d');m.translate(16,h/2);m.filter='blur(4px)';m.beginPath();m.moveTo(0,0);m.arc(0,0,f.r-5,-f.halfAngle,f.halfAngle);m.closePath();m.fillStyle='#fff';m.fill();coneMasks.set(key,mask)}
  if(coneCanvas.width!==w||coneCanvas.height!==h){coneCanvas.width=w;coneCanvas.height=h}
  const z=coneContext;z.setTransform(1,0,0,1,0,0);z.clearRect(0,0,w,h);z.globalCompositeOperation='source-over';blit(z,f.id,Math.min(.999,f.t/f.life),16+f.r/2,h/2,{width:f.r,height:2*f.r*Math.sin(f.halfAngle),alpha:f.alpha});z.globalCompositeOperation='destination-in';z.drawImage(mask,0,0);z.globalCompositeOperation='source-over';
  c.save();c.translate(f.x,f.y);c.rotate(f.angle);c.drawImage(coneCanvas,-16,-h/2);c.restore();if(c.canvas?.id==='cv'){renderStats.mainDraws++;renderStats.byId[f.id]=(renderStats.byId[f.id]||0)+1}return true;
 }
 function legacy(kind,x,y,o={},curId){const keep=new Set(['monsterSheetDeath']);if(keep.has(kind))return false;if(kind==='castStart')return true;
  if(kind==='falcon'){const c=current;const target=o.t||c?.t;if(target){projectile('hn_blitz',{x,y},target,{life:.28,size:70});if(c)c.v8Flight=true;log('hn_blitz',c?'flight':'auto')}return true}
  if(kind==='flask'&&o.acid){projectile('al_acid',{x,y},{x:o.tx,y:o.ty,isMon:true,r:16},{life:.2});return true}
  const progression={levelup:'ac_bless',jobup:'sg_seal',pickup:'me_wit',death:'as_cloak',monDeath:'as_reaper'};
  if(progression[kind]){emit(progression[kind],x,y-22,{size:kind==='levelup'||kind==='jobup'?112:64,life:kind==='levelup'||kind==='jobup'?1.2:.55});return true}
  if(current&&curId)return true;
  if(kind==='link'&&o.t){emit('cr_oath',(x+o.t.x)/2,(y+o.t.y)/2-15,{width:Math.hypot(o.t.x-x,o.t.y-y),height:42,angle:Math.atan2(o.t.y-y,o.t.x-x),life:.5});return true}
  if(kind==='revive'){emit('pr_resu',x,y-30,{size:110,life:1});return true}
  if(kind==='buffUp'||kind==='heal'||kind==='block'){emit(kind==='heal'?'ac_heal':kind==='block'?'cr_guard':'ac_bless',x,y-26,{size:64,life:.5,alpha:.6});return true}if(kind==='trapSet')return true;
  // All generic combat/progression effects also use the new frame artwork.
  if(kind==='arrow'&&o.t){projectile('ar_double',{x,y},o.t,{life:o.life||.3,size:58});return true}
  if(kind==='mbolt'&&o.t){projectile(o.el===1?'mg_cold':o.el===4?'mg_light':'mg_fire',{x,y},o.t,{life:o.life||.28,size:54});return true}
  if(kind==='swing'||kind==='slash'){emit(o.wt==='dagger'?'th_double':o.wt==='axe'?'me_smash':'sw_bash',x+Math.cos(o.a||0)*20,y-22+Math.sin(o.a||0)*20,{angle:o.a||0,size:65,life:.32});return true}
  if(kind==='flask'){projectile('al_bomb',{x,y},{x:o.tx,y:o.ty,isMon:true,r:16},{life:.3,size:54});return true}
  const generic={hit:'sw_bash',impact:'me_smash',nova:'mg_wave',dash:'th_back',falconCircle:'hn_bond',coins:'me_haggle',pickup:'me_wit',levelup:'ac_bless',jobup:'sg_seal',death:'as_cloak',monDeath:'as_reaper'};
  if(generic[kind]){emit(generic[kind],x,y-22,{size:kind==='impact'?Math.max(72,(o.r||40)*2):kind==='levelup'||kind==='jobup'?112:64,life:kind==='levelup'||kind==='jobup'?1.2:.55,angle:['dash','hit'].includes(kind)?(o.a||0):0});return true}return false;
 }
 function depth(f){if(f.target&&f.follow)return f.target.y;if(f.projectile){const p=Math.max(0,Math.min(1,f.t/f.life)),ty=f.target?body(f.target):f.ty;return f.y+(ty-f.y)*p+34}return f.y+(data[f.id]?.grounded?0:34)}
 function compat(id,x,y,size,o={}){id=idOf(id);return emit(id,x,y,{size:size||72,...o})}
 function status(c,m,t,kind){const id=({poison:'as_cloud',freeze:'mg_frost',root:'hn_ankle',reflect:'cr_reflect',enrage:'al_berserk'})[kind];if(!id)return false;return blit(c,id,(t*.8)%1,0,kind==='root'?0:-(m.r||14)*.7,{slots:kind==='root'?[4]:[3,4,5,6,7,8],size:Math.max(32,(m.r||14)*(kind==='root'?2:3)),alpha:kind==='freeze'?.4:.3})}
 function castId(id){let d=data[id]||{};return d.element===3?'cast_fire':d.element===1?'cast_ice':d.element===4||id.startsWith('as_')||id.startsWith('th_')?'cast_arcane':id.startsWith('pr_')||id.startsWith('ac_')||d.mode==='ally'||d.mode==='party'?'cast_holy':'cast_arcane'}
 function casting(c,u,t){const cast=u.cast,id=cast?.c?.s?.id;if(!id||!cast.total||u.dead)return false;const progress=Math.max(0,Math.min(.999,cast.t/cast.total));return blit(c,castId(id),progress,u.x,u.y,{width:100,height:100,alpha:.65+progress*.25})}
 async function preload(){await SafeImages.group(data,images,'skill')}
 return {depth,renderStats,casting,castId,blit,emit,draw:render,begin,end,timeline,cast,projectile,impact,heal,learn,observe,passive,basicHits,regen,drawBuffs,ground,trap,trapTriggered,drawGrounds,legacy,compat,status,preload,images,data,events,stats};
})();

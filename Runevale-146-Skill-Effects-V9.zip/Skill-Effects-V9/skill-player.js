/* Runevale V8: native sprite-sheet skill VFX. No legacy FXPK images. */
window.SkillEffects=(()=>{
 const data={...window.SKILL_FX_DATA,...(window.CAST_FX_DATA||{})},images={},events=[],stats={},learned=new WeakMap();let current=null;const stack=[];
 const blendCanvas=document.createElement('canvas');blendCanvas.width=blendCanvas.height=128;const blendContext=blendCanvas.getContext('2d');
 const alias={hn_mine_x:'hn_mine',hn_mine_t:'hn_mine',hn_ankle_t:'hn_ankle',hn_clay_t:'hn_clay',hn_clay_z:'hn_clay',al_bomb_z:'al_bomb',sg_seal_z:'sg_seal',st_poison:'as_cloud'};
 const idOf=id=>data[id]?id:alias[id];
 function log(id,phase,extra={}){if(!data[id])return;let s=stats[id]||(stats[id]={});s[phase]=(s[phase]||0)+1;events.push({id,phase,...extra});if(events.length>2048)events.shift()}
 function body(p){return p.y-(p.isMon&&window.MonsterSheets?MonsterSheets.height(p)*.5:34)}
 function blit(c,id,phase,x,y,o={}){id=idOf(id);let d=data[id],im=images[id];if(!d||!im?.naturalWidth)return false;const slots=o.slots||Array.from({length:d.frameCount||9},(_,i)=>i),p=Math.min(.999999,Math.max(0,phase))*slots.length,index=Math.min(slots.length-1,Math.floor(p)),i=o.slot??slots[index],w=o.width||o.size||76,h=o.height||w;c.save();c.translate(x,y);if(o.angle)c.rotate(o.angle);const alpha=c.globalAlpha*(o.alpha??.85);c.imageSmoothingEnabled=true;c.imageSmoothingQuality='high';const blend=o.slot==null&&index<slots.length-1?Math.max(0,(p-index-.35)/.65):0;c.globalAlpha=alpha;if(blend>0){const z=blendContext;z.clearRect(0,0,128,128);z.globalCompositeOperation='source-over';z.globalAlpha=1-blend;z.drawImage(im,i*128,0,128,128,0,0,128,128);z.globalCompositeOperation='lighter';z.globalAlpha=blend;z.drawImage(im,slots[index+1]*128,0,128,128,0,0,128,128);z.globalAlpha=1;z.globalCompositeOperation='source-over';c.drawImage(blendCanvas,-w/2,-h/2,w,h)}else c.drawImage(im,i*128,0,128,128,-w/2,-h/2,w,h);c.restore();return true}
 function emit(id,x,y,o={}){id=idOf(id);if(!data[id]||typeof W==='undefined'||!W?.fx||W.fx.length>400)return null;const f={kind:'skillV8',id,x,y,t:-(o.delay||0),life:o.life||data[id].duration||.72,...o};delete f.delay;W.fx.push(f);return f}
 function boundary(c,id,x,y,r,alpha=.2){if(!r)return;const el=data[id]?.element,col=el===3?'#ff9254':el===1?'#9beaff':el===4?'#d4b5ff':el===5?'#a1e880':id.startsWith('ro_')?'#bb92eb':'#e8d1a0';c.save();c.strokeStyle=col;c.globalAlpha*=alpha;c.lineWidth=1.25;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.stroke();c.restore()}
 function draw(c,f){if(f.t<0)return;let p=Math.max(0,Math.min(.999,f.t/f.life)),x=f.x,y=f.y,opts={...f};if(f.target&&f.follow){x=f.target.x;y=body(f.target)}if(f.projectile){let tx=f.target?f.target.x:f.tx,ty=f.target?body(f.target):f.ty;x=f.x+(tx-f.x)*p;y=f.y+(ty-f.y)*p;opts.angle=Math.atan2(ty-f.y,tx-f.x)-(f.baseAngle||0)}opts.alpha=(opts.alpha??.85)*Math.min(1,p*16,(1-p)*8);if(f.radius)boundary(c,f.id,f.x,f.y,f.radius,.22*Math.min(1,(1-p)*8));return blit(c,f.id,p,x,y,opts)}
 function begin(c){stack.push(current);current=c;c.v8Origin={x:c.src.x,y:c.src.y};c.v8Duration=data[c.s.id]?.duration||.72;c.v8Hit=false;c.v8Heal=false;c.v8Flight=false}
 function end(){current=stack.pop()||null}
 function timeline(c,o,t){if(!c?.s||!data[c.s.id])return;const hits=o.hits||1,span=(o.start||0)+(hits-1)*(o.delay||.06)+.4;c.v8Duration=Math.max(c.v8Duration||.72,span);if(!c.s&&hits>1)return;}
 function projectile(id,from,target,o={}){const tx=target.x,ty=body(target),sx=from.x,sy=body(from);return emit(id,sx,sy,{projectile:true,target,tx,ty,life:o.life||Math.max(.14,Math.min(.4,Math.hypot(tx-sx,ty-sy)/1000)),size:60,alpha:.85,...o})}
 function impact(t,info,u){const id=idOf(info.src);if(!data[id])return false;log(id,'hit',{target:t.id||null});if(current?.s.id===id)current.v8Hit=true;const m=data[id],ang=Math.atan2(t.y-u.y,t.x-u.x);return !!emit(id,t.x,body(t),{target:t,follow:false,size:Math.max(46,Math.min(96,(t.r||15)*3)),angle:['projectile','dash'].includes(m.mode)?ang:0,slots:[3,4,5,6,7,8],life:.35,alpha:.72})}
 function radius(c){return c.s.id==='kn_brand'&&c.src.peco?5*T:Math.max(0,(typeof c.s.r==='number'?c.s.r:0)*T)}
 function cast(c){const id=c.s.id,d=data[id];if(!d||d.type==='passive')return false;if(id==='hn_blitz'&&!c.src.falcon)return false;if(id==='al_potion'&&!c.v8Heal)return false;log(id,'cast',{level:c.lv});emit(castId(id),c.src.x,c.src.y,{width:68,height:32,life:.45,alpha:.45,layer:'ground'});if(c.v8Heal||id==='mo_orbs')return true;let src=c.src,tg=c.t,ally=c.ally||src,org=c.v8Origin||{x:src.x,y:src.y},r=radius(c),p={x:c.x??tg?.x??src.x,y:c.y??tg?.y??src.y};const life=Math.min(2.5,c.v8Duration||d.duration||.72);
  if(['ac_heal','cr_heal'].includes(id)&&(tg?.isMon||!c.v8Heal))return true;
  if(d.mode==='trap')return true;
  if(d.persistentGround)return true;
  if(d.mode==='teleport'){emit(id,org.x,org.y-12,{size:74,life:.55});emit(id,src.x,src.y-12,{size:74,life:.65});return true}
  if(d.mode==='dash'){let dest=id==='cr_rush'?(tg||src):src,dx=dest.x-org.x,dy=dest.y-org.y;emit(id,(org.x+dest.x)/2,(org.y+dest.y)/2-24,{width:Math.max(72,Math.hypot(dx,dy)),height:65,angle:Math.atan2(dy,dx)-(id==='th_back'?Math.PI:0),life});return true}
  if(d.mode==='cone'){let a=tg?Math.atan2(tg.y-src.y,tg.x-src.x):src.face||0;emit(id,src.x,src.y,{cone:true,angle:a,r:6*T,halfAngle:35*Math.PI/180,life,layer:'ground',alpha:.7});return true}
  if(d.mode==='projectile'){if(c.v8Flight)return true;if(id==='al_acid')return true;if(c.v8Heal)return true;const dest=tg||c.ally||src;projectile(id,src,dest,{size:id==='ar_double'?74:64});return true}
  if(d.mode==='party'){for(let a of allyList(src)){if(dist(a,src)<=(d.partyRadius||13)*T)emit(id,a.x,body(a),{target:a,follow:true,size:78,life:1,alpha:.8})}return true}
  if(d.mode==='selfArea'||d.mode==='ground'||d.mode==='targetArea'){let pos=d.mode==='selfArea'?src:d.mode==='targetArea'?tg:p;if(!pos)pos=src;emit(id,pos.x,pos.y,{size:Math.max(70,r*2),radius:r,life,layer:'ground',alpha:.65});return true}
  if(d.mode==='ally'){if(!c.v8Heal)emit(id,ally.x,body(ally),{target:ally,follow:true,size:id==='pr_resu'?110:80,life:1});return true}
  if(d.mode==='self'||d.mode==='craft'){emit(id,src.x,body(src),{target:src,follow:true,size:80,life:1});return true}
  if(!c.v8Hit&&tg)emit(id,tg.x,body(tg),{size:76,life});return true;
 }
 function heal(u,value,src){if(!current?.s||!data[current.s.id])return;const id=current.s.id;if(!['firstaid','ac_heal','cr_heal','al_potion'].includes(id))return;current.v8Heal=true;log(id,'heal');if(id==='al_potion'){projectile(id,src||current.src,u);emit(id,u.x,body(u),{target:u,follow:true,size:76,life:.7,delay:.1,slots:[3,4,5,6,7,8]})}else emit(id,u.x,body(u),{target:u,follow:true,size:76,life:.8})}
 function learn(u,id){if(!data[id]||data[id].type!=='passive')return false;log(id,'learn');return !!emit(id,u.x,body(u),{target:u,follow:true,size:66,life:.8})}
 function observe(u){if(!u.skills)return;let old=learned.get(u);if(!old){old={...u.skills};learned.set(u,old);return}for(let [id,lv]of Object.entries(u.skills)){if(data[id]?.type==='passive'&&lv>(old[id]||0))learn(u,id);old[id]=lv}}
 function passive(u,id,t){if(!(u.skills?.[id]>0)||data[id]?.type!=='passive')return false;log(id,'proc');return !!emit(id,t?.x??u.x,t?body(t):body(u),{size:66,life:.5})}
 function basicHits(c,o,t){if(c.s)return;if(o.hits===3&&c.src.skills?.mo_triple)passive(c.src,'mo_triple',t);else if(o.hits===2&&c.src.wt==='dagger'&&c.src.skills?.th_double)passive(c.src,'th_double',t)}
 function regen(u,hp,sp){if(hp>0&&u.skills?.sw_regen)passive(u,'sw_regen');if(sp>0&&u.skills?.mg_sp)passive(u,'mg_sp')}
 function buffId(key,b){return idOf(b.sk||key)||(key==='oath'?'cr_oath':null)}
 function drawBuffs(c,u,t){observe(u);const active=Object.entries(u.buffs||{}).filter(([key,b])=>data[buffId(key,b)]);const start=active.length>3?Math.floor(t/2)%active.length:0;for(let n=0;n<Math.min(3,active.length);n++){let[key,b]=active[(start+n)%active.length],id=buffId(key,b);if(id==='wz_mshield'&&u.sp<derive(u).maxSP*.01)continue;if(id==='mo_orbs'){let count=Math.max(1,Math.min(5,b.orbs||1));for(let i=0;i<count;i++){let a=t*1.8+i*Math.PI*2/count;blit(c,'mo_shot',0,u.x+Math.cos(a)*24,body(u)+Math.sin(a)*10,{slot:0,size:19,alpha:.8})}continue}blit(c,id,(t*.7)%1,u.x,body(u),{slots:[1,2,3,4,5,6,7,6,5,4,3,2],size:id==='mg_sight'?90:74,alpha:.26})}
  if(u.cast?.c?.s){const id=u.cast.c.s.id;/* casting visuals are drawn beneath the actor by casting() */}
 }
 const zoneFallback={pneuma:'wz_pneuma',quag:'wz_quag',blizzard:'wz_storm',magnus:'pr_magnus',sanct:'pr_sanct',safety:'pr_safety',seal:'sg_seal',firebomb:'al_bomb',burn:'hn_clay',water:'sg_water'};
 function ground(c,g,t){let id=idOf(g.sk)||zoneFallback[g.kind];if(!data[id])return false;let fade=Math.max(0,Math.min(1,g.t));boundary(c,id,g.x,g.y,g.r,.18*fade);return blit(c,id,(t*.8)%1,g.x,g.y,{slots:[1,2,3,4,5,6,7,6,5,4,3,2],size:g.r*2,alpha:.42*fade})}
 function trap(c,tr,t,mine){const id=tr.c?.s?.id||({mine:'hn_mine',ankle:'hn_ankle',clay:'hn_clay'}[tr.kind]);if(!data[id])return false;return blit(c,id,0,tr.x,tr.y,{slot:0,size:43,alpha:mine?.9:.45})}
 function trapTriggered(tr){const id=tr.c?.s?.id||({mine:'hn_mine',ankle:'hn_ankle',clay:'hn_clay'}[tr.kind]);log(id,'trigger');return emit(id,tr.x,tr.y,{slots:[3,4,5,6,7,8],size:Math.max(70,tr.r*2),life:.6,layer:'ground'})}
 function drawGrounds(c,t){for(let g of W.grounds)ground(c,g,t);for(let tr of W.traps)trap(c,tr,t,tr.owner===P);for(let f of W.fx)if(f.kind==='skillV8'&&f.layer==='ground')render(c,f)}
 function render(c,f){if(!f.cone)return draw(c,f);if(f.t<0)return;c.save();c.translate(f.x,f.y);c.rotate(f.angle);c.beginPath();c.moveTo(0,0);c.arc(0,0,f.r,-f.halfAngle,f.halfAngle);c.closePath();c.save();c.globalAlpha*=.22;c.strokeStyle='#ffb36d';c.lineWidth=1.25;c.stroke();c.restore();c.clip();blit(c,f.id,Math.min(.999,f.t/f.life),f.r/2,0,{width:f.r,height:2*f.r*Math.sin(f.halfAngle),alpha:f.alpha});c.restore()}
 function legacy(kind,x,y,o={},curId){const keep=new Set(['monsterSheetDeath','monDeath','levelup','jobup','death','pickup']);if(keep.has(kind))return false;if(kind==='castStart')return true;
  if(kind==='falcon'){const c=current;const target=o.t||c?.t;if(target){projectile('hn_blitz',{x,y},target,{life:.28,size:70});if(c)c.v8Flight=true;log('hn_blitz',c?'flight':'auto')}return true}
  if(kind==='flask'&&o.acid){projectile('al_acid',{x,y},{x:o.tx,y:o.ty,isMon:true,r:16},{life:.2});return true}
  if(current&&curId)return true;
  if(kind==='link'&&o.t){emit('cr_oath',(x+o.t.x)/2,(y+o.t.y)/2-15,{width:Math.hypot(o.t.x-x,o.t.y-y),height:42,angle:Math.atan2(o.t.y-y,o.t.x-x),life:.5});return true}
  if(kind==='revive'){emit('pr_resu',x,y-30,{size:110,life:1});return true}
  if(kind==='buffUp'||kind==='heal'||kind==='block'){emit(kind==='heal'?'ac_heal':kind==='block'?'cr_guard':'ac_bless',x,y-26,{size:64,life:.5,alpha:.6});return true}if(kind==='trapSet')return true;return false;
 }
 function compat(id,x,y,size,o={}){id=idOf(id);return emit(id,x,y,{size:size||72,...o})}
 function status(c,m,t,kind){const id=({poison:'as_cloud',freeze:'mg_frost',root:'hn_ankle',reflect:'cr_reflect',enrage:'al_berserk'})[kind];if(!id)return false;return blit(c,id,(t*.8)%1,0,kind==='root'?0:-(m.r||14)*.7,{slots:kind==='root'?[4]:[3,4,5,6,7,8],size:Math.max(32,(m.r||14)*(kind==='root'?2:3)),alpha:kind==='freeze'?.4:.3})}
 function castId(id){let d=data[id]||{};return d.element===3?'cast_fire':d.element===1?'cast_ice':d.element===4||id.startsWith('as_')||id.startsWith('th_')?'cast_arcane':id.startsWith('pr_')||id.startsWith('ac_')||d.mode==='ally'||d.mode==='party'?'cast_holy':'cast_arcane'}
 function casting(c,u,t){const cast=u.cast,id=cast?.c?.s?.id;if(!id||!cast.total||u.dead)return false;const progress=Math.max(0,Math.min(.999,cast.t/cast.total));return blit(c,castId(id),progress,u.x,u.y,{width:90,height:44,alpha:.5+progress*.25})}
 async function preload(){await Promise.all(Object.entries(data).map(async([id,d])=>{let im=new Image();im.src=d.src;images[id]=im;await im.decode()}))}
 return {casting,castId,blit,emit,draw:render,begin,end,timeline,cast,projectile,impact,heal,learn,observe,passive,basicHits,regen,drawBuffs,ground,trap,trapTriggered,drawGrounds,legacy,compat,status,preload,images,data,events,stats};
})();

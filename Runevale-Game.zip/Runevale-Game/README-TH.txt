วิธีเปิดเกม Runevale Online

1. แตกไฟล์ ZIP
2. เปิดไฟล์ index.html ด้วย Chrome หรือ Edge

ไฟล์เกมรวมภาพแมพและแอสเซ็ตไว้แล้ว

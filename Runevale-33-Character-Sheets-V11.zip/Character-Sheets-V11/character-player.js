/* Character anatomy is drawn only from atlas pixels. */
window.SheetPlayer=(()=>{
 const images={},dirs=['S','SW','W','NW','N','NE','E','SE'],tracks=new WeakMap(),clips={};
 for(const[id,d]of Object.entries(SHEET_DATA)){clips[id]={};for(const f of d.frames){const key=f.direction+'/'+f.action;(clips[id][key]||(clips[id][key]=[])).push(f)}for(const fs of Object.values(clips[id]))fs.sort((a,b)=>a.frame-b.frame)}
 const direction=a=>((Math.round((a-Math.PI/2)/(Math.PI/4))%8)+8)%8;
 function choose(u,t,moving){
  const id=SHEET_DATA[u.cls]?u.cls:'novice';let st=tracks.get(u);
  if(!st){st={x:u.x,y:u.y,time:t,walkTime:0,dir:direction(u.face??Math.PI/2),travel:false};tracks.set(u,st)}
  if(t!==st.time){const dx=u.x-st.x,dy=u.y-st.y,dt=t-st.time,ds=Math.hypot(dx,dy);st.travel=dt>0&&Number.isFinite(ds)&&ds>.005&&ds<=Math.max(24,dt*600);
   if(st.travel){const a=Math.atan2(dy,dx),center=Math.PI/2+st.dir*Math.PI/4,error=Math.abs(Math.atan2(Math.sin(a-center),Math.cos(a-center)));if(error>Math.PI/8+.07)st.dir=direction(a);st.walkTime+=Math.min(dt,.1)*Math.max(.65,Math.min(1.4,ds/dt/120))}
   else{st.walkTime=0;if(Number.isFinite(u.face))st.dir=direction(u.face)}
   st.x=u.x;st.y=u.y;st.time=t;
  }
  const state=u.dead?'down':u.cast?'cast':u.anim?'attack':st.travel?'walk':'idle';
  const action=state==='down'?'idle':state==='cast'?'attack':state;
  if(state==='attack'||state==='cast')st.dir=direction(u.face??Math.PI/2);
  const dir=dirs[st.dir],frames=clips[id][dir+'/'+action];let phase=0;
  if(state==='walk')phase=Math.floor((st.walkTime+1e-8)/.24)%frames.length;
  else if(state==='attack')phase=Math.min(frames.length-1,Math.max(0,Math.floor(u.anim.t/Math.max(.001,u.anim.d)*frames.length)));
  else if(state==='idle')phase=Math.floor(t/.65)%frames.length;
  // Cast holds the existing anticipation drawing; down holds a sheet frame.
  return {id,state,action,dir,phase,frame:frames[phase]};
 }
 function draw(c,u,t,moving){const pick=choose(u,t,moving),f=pick.frame,im=images[pick.id];if(!f||!im?.naturalWidth)return false;c.save();c.translate(u.x,u.y);c.fillStyle='rgba(0,0,0,.23)';c.beginPath();c.ellipse(0,3,12,4,0,0,Math.PI*2);c.fill();if(u.dead)c.globalAlpha*=.55;if(u.buffs?.hide)c.globalAlpha*=.4;const s=.72;c.imageSmoothingEnabled=false;c.drawImage(im,...f.rect,-f.pivot[0]*s,-f.pivot[1]*s,f.rect[2]*s,f.rect[3]*s);c.restore();return true}
 async function preload(){await SafeImages.group(SHEET_DATA,images,'character')}
 return {choose,draw,preload,images,clips,directions:dirs};
})();

/* Four authored directions. Anatomy is read from atlas pixels only. */
window.SheetPlayer=(()=>{
 const images={},dirs=['E','S','W','N'],tracks=new WeakMap(),clips={};
 for(const[id,d]of Object.entries(SHEET_DATA)){clips[id]={};for(const f of d.frames)(clips[id][f.direction+'/'+f.action]??=[]).push(f);for(const fs of Object.values(clips[id]))fs.sort((a,b)=>a.frame-b.frame)}
 const direction=a=>((Math.round(a/(Math.PI/2))%4)+4)%4;
 function choose(u,t,moving){const id=SHEET_DATA[u.cls]?u.cls:'novice';let st=tracks.get(u);if(!st){st={x:u.x,y:u.y,time:t,distance:0,dir:direction(u.face??Math.PI/2),travel:false,deadAt:null};tracks.set(u,st)}
  if(t!==st.time){const dx=u.x-st.x,dy=u.y-st.y,dt=t-st.time,ds=Math.hypot(dx,dy);st.travel=dt>0&&Number.isFinite(ds)&&ds>.005&&ds<=Math.max(24,dt*600);
   if(st.travel){const a=Math.atan2(dy,dx),center=st.dir*Math.PI/2,error=Math.abs(Math.atan2(Math.sin(a-center),Math.cos(a-center)));if(error>Math.PI/4+.08)st.dir=direction(a);st.distance+=ds}
   else{st.distance=0;if(Number.isFinite(u.face))st.dir=direction(u.face)}st.x=u.x;st.y=u.y;st.time=t;
  }
  let state=u.dead?'down':u.cast?'cast':u.anim?'attack':st.travel?'walk':'idle';if(!u.dead)st.deadAt=null;else if(st.deadAt===null)st.deadAt=t;
  if(state==='attack'||state==='cast')st.dir=direction(u.face??Math.PI/2);
  const dir=state==='down'?'S':dirs[st.dir],action=state==='cast'?'attack':state,frames=clips[id][dir+'/'+action];let phase=0;
  if(state==='walk')phase=Math.floor((st.distance+1e-8)/28)%frames.length;
  else if(state==='attack')phase=Math.max(0,Math.min(frames.length-1,Math.floor((u.anim.t||0)/Math.max(.001,u.anim.d||.3)*frames.length)));
  else if(state==='down')phase=t-st.deadAt<.16?0:frames.length-1;
  // Charging holds the authored anticipation pose, without deforming the body.
  return {id,state,action,dir,phase,frame:frames[phase],distance:st.distance};
 }
 function draw(c,u,t,moving){const p=choose(u,t,moving),f=p.frame,im=images[p.id];if(!f||!im?.naturalWidth)return false;c.save();c.translate(u.x,u.y);c.fillStyle='rgba(0,0,0,.21)';c.beginPath();c.ellipse(0,3,12,4,0,0,Math.PI*2);c.fill();if(u.buffs?.hide)c.globalAlpha*=.4;const s=.65;c.imageSmoothingEnabled=false;c.drawImage(im,...f.rect,-f.pivot[0]*s,-f.pivot[1]*s,f.rect[2]*s,f.rect[3]*s);c.restore();return true}
 async function preload(){await SafeImages.group(SHEET_DATA,images,'character')}
 return {choose,draw,preload,images,clips,directions:dirs,version:32};
})();
